﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsApplication3.MVVM {
    public class Test {
        public int ID { get; set; }
        public string Text { get; set; }
    }
}
