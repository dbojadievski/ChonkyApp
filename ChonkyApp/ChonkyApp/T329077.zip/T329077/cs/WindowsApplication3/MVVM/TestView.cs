﻿using System;
using System.Collections.Generic;
using System.Linq;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;

namespace WindowsApplication3.MVVM {
    public partial class TestView : DevExpress.XtraEditors.XtraUserControl {
        public TestView() {
            InitializeComponent();
            if (!DesignMode) {
                mvvmContext1.ViewModelType = typeof(TestViewModel);
                var fluentApi = mvvmContext1.OfType<TestViewModel>();
                fluentApi.SetBinding(imageComboBoxEdit1, c => c.EditValue, x => x.TimeOfDay);
                fluentApi.SetBinding(radioGroup1, c => c.EditValue, x => x.TimeOfDay);
            }
            SetupEditors();
        }
        private void SetupEditors() {
            imageComboBoxEdit1.Properties.Items.AddEnum(typeof(TimeOfDay));
            foreach (ImageComboBoxItem item in imageComboBoxEdit1.Properties.Items)
                radioGroup1.Properties.Items.Add(new RadioGroupItem(item.Value, item.Description));
        }
    }
}
