﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace WindowsApplication3.MVVM {
    public enum TimeOfDay {
        Morning,
        Noon,
        Evening,
        Night
    }
    public class TestViewModel {
        public TestViewModel() {
            Entities = new ObservableCollection<Test>();
            for (int i = 0; i < 10; i++)
                Add();
        }
        public virtual Test SelectedEntity { get; set; }
        public virtual ObservableCollection<Test> Entities { get; set; }
        public void Add() {
            Entities.Add(new Test() { ID = Entities.Count, Text = string.Format("Test {0}", Entities.Count) });
        }
        public void Sort(bool ascending) {
            if (ascending)
                Entities = new ObservableCollection<Test>(Entities.OrderBy(t => t.Text));
            else
                Entities = new ObservableCollection<Test>(Entities.OrderByDescending(t => t.Text));
        }

        public virtual bool Checked { get; set; }
        public virtual TimeOfDay TimeOfDay { get; set; }

    }
}
