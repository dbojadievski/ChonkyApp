using System;
using System.Collections.Generic;
using System.Linq;
using DevExpress.XtraEditors;


namespace WindowsApplication3 {
    public partial class Main : XtraForm {

        public Main() {
            InitializeComponent();
        }
    }
}

