﻿Imports Microsoft.VisualBasic
Imports System
Namespace WindowsApplication3.MVVM
	Partial Public Class TestView
		''' <summary> 
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary> 
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Component Designer generated code"

		''' <summary> 
		''' Required method for Designer support - do not modify 
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.components = New System.ComponentModel.Container()
			Me.mvvmContext1 = New DevExpress.Utils.MVVM.MVVMContext(Me.components)
			Me.radioGroup1 = New DevExpress.XtraEditors.RadioGroup()
			Me.imageComboBoxEdit1 = New DevExpress.XtraEditors.ImageComboBoxEdit()
			CType(Me.mvvmContext1, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.radioGroup1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.imageComboBoxEdit1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' mvvmContext1
			' 
			Me.mvvmContext1.ContainerControl = Me
			Me.mvvmContext1.RegistrationExpressions.AddRange(New DevExpress.Utils.MVVM.RegistrationExpression() { DevExpress.Utils.MVVM.RegistrationExpression.RegisterDocumentManagerService(Nothing, False, Nothing)})
			Me.mvvmContext1.ViewModelType = GetType(WindowsApplication3.MVVM.TestViewModel)
			' 
			' radioGroup1
			' 
			Me.radioGroup1.Location = New System.Drawing.Point(19, 13)
			Me.radioGroup1.Name = "radioGroup1"
			Me.radioGroup1.Size = New System.Drawing.Size(368, 158)
			Me.radioGroup1.TabIndex = 10
			' 
			' imageComboBoxEdit1
			' 
			Me.imageComboBoxEdit1.Location = New System.Drawing.Point(19, 195)
			Me.imageComboBoxEdit1.Name = "imageComboBoxEdit1"
			Me.imageComboBoxEdit1.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() { New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
			Me.imageComboBoxEdit1.Size = New System.Drawing.Size(368, 20)
			Me.imageComboBoxEdit1.TabIndex = 11
			' 
			' TestView
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.Controls.Add(Me.imageComboBoxEdit1)
			Me.Controls.Add(Me.radioGroup1)
			Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
			Me.Name = "TestView"
			Me.Size = New System.Drawing.Size(448, 272)
			CType(Me.mvvmContext1, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.radioGroup1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.imageComboBoxEdit1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private mvvmContext1 As DevExpress.Utils.MVVM.MVVMContext
		Private imageComboBoxEdit1 As DevExpress.XtraEditors.ImageComboBoxEdit
		Private radioGroup1 As DevExpress.XtraEditors.RadioGroup
	End Class
End Namespace
