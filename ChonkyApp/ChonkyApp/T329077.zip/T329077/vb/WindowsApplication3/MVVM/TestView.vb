﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports DevExpress.XtraEditors
Imports DevExpress.XtraEditors.Controls

Namespace WindowsApplication3.MVVM
	Partial Public Class TestView
		Inherits DevExpress.XtraEditors.XtraUserControl
		Public Sub New()
			InitializeComponent()
			If (Not DesignMode) Then
				mvvmContext1.ViewModelType = GetType(TestViewModel)
				Dim fluentApi = mvvmContext1.OfType(Of TestViewModel)()
				fluentApi.SetBinding(imageComboBoxEdit1, Function(c) c.EditValue, Function(x) x.TimeOfDay)
				fluentApi.SetBinding(radioGroup1, Function(c) c.EditValue, Function(x) x.TimeOfDay)
			End If
			SetupEditors()
		End Sub
		Private Sub SetupEditors()
			imageComboBoxEdit1.Properties.Items.AddEnum(GetType(TimeOfDay))
			For Each item As ImageComboBoxItem In imageComboBoxEdit1.Properties.Items
				radioGroup1.Properties.Items.Add(New RadioGroupItem(item.Value, item.Description))
			Next item
		End Sub
	End Class
End Namespace
