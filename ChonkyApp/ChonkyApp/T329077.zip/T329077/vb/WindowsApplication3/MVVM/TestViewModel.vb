﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Collections.ObjectModel
Imports System.Linq

Namespace WindowsApplication3.MVVM
	Public Enum TimeOfDay
		Morning
		Noon
		Evening
		Night
	End Enum
	Public Class TestViewModel
		Public Sub New()
			Entities = New ObservableCollection(Of Test)()
			For i As Integer = 0 To 9
				Add()
			Next i
		End Sub
		Public Overridable Property SelectedEntity() As Test
		Public Overridable Property Entities() As ObservableCollection(Of Test)
		Public Sub Add()
			Entities.Add(New Test() With {.ID = Entities.Count, .Text = String.Format("Test {0}", Entities.Count)})
		End Sub
		Public Sub Sort(ByVal ascending As Boolean)
			If ascending Then
				Entities = New ObservableCollection(Of Test)(Entities.OrderBy(Function(t) t.Text))
			Else
				Entities = New ObservableCollection(Of Test)(Entities.OrderByDescending(Function(t) t.Text))
			End If
		End Sub

		Public Overridable Property Checked() As Boolean
        Public Overridable Property TimeOfDay() As TimeOfDay

	End Class
End Namespace
